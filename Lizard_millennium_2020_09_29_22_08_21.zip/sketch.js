var monkey = createSprite(20, 300, 30, 20);
monkey.setAnimation("monkey");
monkey.scale = 0.15;

var ground = createSprite(200, 360, 400, 10);
ground.x=ground.width/2;

var stoneGroup = createGroup();

var foodGroup = createGroup();

var survivalTime = 0;

function draw() {

background("white");

textSize(20);
survivalTime=Math.ceil(World.frameCount/World.frameRate);
text("Survival Time: "+survivalTime,100,50);

ground.velocityX = -9;

if (ground.x<0) {
 ground.x = ground.width/2;   
  }
    
console.log(monkey.y);

if (keyDown("space")&& monkey.y>=306) {
   monkey.velocityY = -10; 
  }
 
 obi();
 food();
 
 monkey.y = monkey.y+0.8;
 
 monkey.collide(ground);
    
drawSprites();
}

function obi () {
 if (World.frameCount %300 === 0) {
  var stone = createSprite(400, 350, 10, 50);
  stone.setAnimation("Stone");
  stone.scale=0.15;
  stone.lifetime = 100;
  stone.velocityX = -9;
  stoneGroup.add(stone);
  }
}
function food() {
if (World.frameCount %80 === 0) {
 var banana = createSprite(400, randomNumber(120,200), 10, 50);
 banana.setAnimation("Banana");
 banana.scale = 0.1;
 banana.lifetime = 100;
 banana.velocityX = -9;
 foodGroup.add(banana);  
 }
}




  
